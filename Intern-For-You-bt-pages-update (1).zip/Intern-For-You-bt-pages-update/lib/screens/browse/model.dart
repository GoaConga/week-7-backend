import 'package:get/get.dart';

class BrowseItemModel {}

class BrowseModel {
  RxList<BrowseItemModel> browseItemModelList = RxList.filled(1, BrowseItemModel());
}
