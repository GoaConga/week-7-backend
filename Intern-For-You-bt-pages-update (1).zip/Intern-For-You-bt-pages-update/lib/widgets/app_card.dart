import 'package:flutter/material.dart';

class AppCard extends StatelessWidget {
  const AppCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //TODO implement Card Widget to use 1 field across the app
    return Container();
  }
}
