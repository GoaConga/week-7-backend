class Qualifications {
  late String qualificationLevel;
  late String courseName;
  late DateTime graduationYear;
}
