import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internsforyou/screens/register/controller.dart';
import 'package:internsforyou/theme/ify_custom_theme.dart';
import 'package:internsforyou/utils/routes/app_routes.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
//
import '../widgets/ify_textfields.dart';

class Signup_Static {
  static final bool isCompamy = true;
  static final _formKey = GlobalKey<FormState>();
  static TextEditingController emailController = TextEditingController();
  static TextEditingController passwordController = TextEditingController();
  static TextEditingController password2Controller = TextEditingController();
}

class RegisterScreen extends GetView<RegisterController> {
  RegisterScreen({Key? key}) : super(key: key);

  //final bool isCompamy = true;
  //final _formKey = GlobalKey<FormState>();
  //TextEditingController emailController = TextEditingController();
  //TextEditingController passwordController = TextEditingController();
  //TextEditingController password2Controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 5),
            child: Form(
              key: Signup_Static._formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Text('${Signup_Static.isCompamy ? 'Company' : 'Personal'} Account Details', style: IFYFonts.introHeader),
                      Container()
                    ],
                  ),
                  Column(
                    children: [
                      Padding(padding: const EdgeInsets.fromLTRB(40, 10, 40, 2), child: primaryTextField('${Signup_Static.isCompamy ? 'company' : 'personal'} email address', 'example@mail.com', false, Signup_Static.emailController, TextInputType.emailAddress, 1, 30)),
                      Padding(padding: const EdgeInsets.fromLTRB(40, 10, 40, 2), child: primaryTextField('password', 'password', true, Signup_Static.passwordController, TextInputType.visiblePassword, 1, 30)),
                      Padding(padding: const EdgeInsets.fromLTRB(40, 10, 40, 2), child: primaryTextField('re-type password', 'password', true, Signup_Static.password2Controller, TextInputType.visiblePassword, 1, 30)),
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: ElevatedButton(
                          child: const Text('Create Account'),
                          style: IFYButtons.primaryButton,
                          onPressed: () {
                            if (Signup_Static._formKey.currentState!.validate()) {
                              doUserRegistration();
                              Get.toNamed(AppRoutes.detailsFormScreen);
                              debugPrint("Username: ${Signup_Static.emailController.text}\nPassword: ${Signup_Static.passwordController.text}");
                              //TODO: Continue if passed
                            } else {
                              debugPrint('false');
                            }
                          },
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void doUserRegistration() async {
    final username = Signup_Static.passwordController.text.trim();
    final email = Signup_Static.emailController.text.trim();
    final password = Signup_Static.passwordController.text.trim();

    final user = ParseUser.createUser(username, password, email);

    var response = await user.signUp();
  }
}
