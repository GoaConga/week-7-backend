import 'package:get/get_state_manager/get_state_manager.dart';

class LoginController extends GetxController {
  //TODO impl. Authorisations!!!
}
