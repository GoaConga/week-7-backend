import 'package:get/get.dart';

class InitialBindings extends Bindings {
  @override
  void dependencies() {
    //TODO: Authorisation & implement if app initialise b4 (Use GetStorage to detect)
  }
}
