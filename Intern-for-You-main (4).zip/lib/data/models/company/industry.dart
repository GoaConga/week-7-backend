class Industry {
  late String industry;
}
