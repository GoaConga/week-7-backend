import 'package:internsforyou/models/company/industry.dart';

class Company {
  late String companyName;
  late String email;
  late String password;
  late int contactNumber;
  late Industry industry;
  late String logo;
  late String bio;
}
